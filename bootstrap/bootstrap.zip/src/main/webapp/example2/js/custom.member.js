/**
 * 
 */
 alert($);